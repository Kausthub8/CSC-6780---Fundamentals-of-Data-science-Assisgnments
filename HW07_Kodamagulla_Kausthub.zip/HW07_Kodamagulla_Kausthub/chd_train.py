import pandas as pd
from sklearn.linear_model import LogisticRegression
import pickle
from sklearn.preprocessing import StandardScaler

# Read the training data
print("Reading input...")

## Your code here
train_data = pd.read_csv("train.csv", index_col=False)

print("Scaling...")
## Your code here
scaler = StandardScaler()


print("Fitting...")
## Your code herer
X_train = train_data.drop(columns=["TenYearCHD"])

# Get the accuracy on the training data
## Your code here
y_train = train_data["TenYearCHD"]
X_train = scaler.fit_transform(X_train)
model = LogisticRegression()
model.fit(X_train, y_train)
train_accuracy = model.score(X_train, y_train)
print(f"Training accuracy = {train_accuracy}")

# Write out the scaler and logisticregression objects into a pickle file
pickle_path = "classifier.pkl"
print(f"Writing scaling and logistic regression model to {pickle_path}...")
## Your code here
with open(pickle_path, "wb") as f:
    pickle.dump((scaler, model), f)
