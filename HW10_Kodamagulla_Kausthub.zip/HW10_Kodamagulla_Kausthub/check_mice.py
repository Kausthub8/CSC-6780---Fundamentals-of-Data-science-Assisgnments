import numpy as np
import pandas as pd
from scipy.stats import chi2

# Read in the data
mice_df = pd.read_csv("mice.csv")

# Figure out the possible gene types
gene_types = list(mice_df.gene_type.unique())
print(f"Possible gene types:{gene_types}")
contingency_table = pd.crosstab(mice_df.gene_type, mice_df.has_cancer, margins = True, margins_name = 'Total')
print(f"contingency_table:\n{contingency_table}\n")

conditional_proportion = contingency_table.iloc[0:4, 0:2].div(contingency_table['Total']*0.01, axis = 0)
conditional_proportion['Total'] = contingency_table['Total'].div(contingency_table['Total'][-1]*0.01)
print(f"conditional_proportion_table:\n{round(conditional_proportion,1)}\n")

expected_counts = pd.DataFrame()
expected_counts['False'] = contingency_table['Total'].mul(conditional_proportion.iloc[-1,0]*0.01)
expected_counts['True'] = contingency_table['Total'].mul(conditional_proportion.iloc[-1,1]*0.01)
expected_counts['Total'] = contingency_table['Total']
expected_counts.iloc[-1, 0:-1] = conditional_proportion.iloc[-1, 0:-1]

print(f"expected_counts_table:\n{round(expected_counts,1)}\n")
chi_squared_stat = ((np.array(contingency_table.iloc[0:3, 0:2]) - np.array(expected_counts.iloc[0:3, 0:2]))**2/np.array(expected_counts.iloc[0:3, 0:2])).sum()
print(f"chi_squared_stat = {chi_squared_stat:.4f}")
dof = (len(gene_types) -1)*(2 - 1)
print(f"degree of freedom: {dof}")
p_value = 1 - chi2.cdf(chi_squared_stat, df = dof)
print(f"p_value: {p_value:.4f}")

