import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import sys

if len(sys.argv) != 2:
    print(f"Usage: {sys.argv[0]} <csv>")
    sys.exit(1)

infilename = sys.argv[1]

df = pd.read_csv(infilename, index_col="property_id")

print("Making new features...")


df["lot_size"] = df["lot_width"] * df["lot_depth"]
df["is_close_to_school"] = (df["miles_to_school"] < 2).astype(int)

new_df = df[["sqft_hvac", "lot_size", "is_close_to_school", "price"]]
print(f"Using only the useful ones: {[i for i in new_df.columns[:-1]]}...")
X_var = new_df.values[:, :-1]
X_var = np.insert(X_var, 0, 1.0, axis=1)
Y_var = new_df.values[:, -1]

lin_reg = LinearRegression(fit_intercept=False)

# Fit the model
lin_reg.fit(X_var, Y_var)
r_squared = lin_reg.score(X_var, Y_var)
# print("R2 = ",r_squared)
print(f"R2 = {r_squared:,.5f}")

print("*** Prediction ***")

coef_vals = lin_reg.coef_
# print(coef_vals)

print(
    f"Price = ${coef_vals[0]:,.2f} + (sqft x ${coef_vals[1]:,.2f}) + (lot_size x ${coef_vals[2]:,.2f})"
)
print(
    f"\tLess than 2 miles from a school? You get ${coef_vals[3]:,.2f} added to the price!"
)

