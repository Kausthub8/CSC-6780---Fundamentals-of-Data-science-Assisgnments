import pandas as pd
import numpy as np
from sklearn.preprocessing import PolynomialFeatures
from scipy.stats import pearsonr
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import sys

# Deal with command-line
if len(sys.argv) != 2:
    print(f"Usage: {sys.argv[0]} <csv>")
    sys.exit(1)
infilename = sys.argv[1]

# Read in the basic data frame
df = pd.read_csv(infilename, index_col="property_id")
X_basic = df.values[:, :-1]
labels_basic = df.columns[:-1]
Y = df.values[:, -1]

# Expand to a 2-degree polynomials
poly = PolynomialFeatures(2)
X_poly = poly.fit_transform(X_basic, Y)

# Poly labels
labels_poly = poly.get_feature_names_out(labels_basic)

# Prepare for loop
residual = Y
# We always need the column of zeros to
# include the intercept
feature_indices = [0]

print("First time through: using original price data as the residual")
while len(feature_indices) < 3:
    p_val_list = []
    label_list = []
    index_list = []
    for i in range(1, len(list(labels_poly))):
        index_list.append(i)
        label_list.append(labels_poly[i])
        p_val_list.append(pearsonr(X_poly[:, i], residual)[1])

    p_val_df = pd.DataFrame(zip(index_list, label_list, p_val_list))
    p_val_df = p_val_df.sort_values(by=2)

    for i in range(len(p_val_df)):
        print(f'\t"{p_val_df.iloc[i, 1]}" vs residual: p-value={p_val_df.iloc[i, 2]}')

    feature_indices.append(p_val_df[0].iloc[0])

    # print(feature_indices)
    model = LinearRegression()
    print(f"**** Fitting with {[labels_poly[i] for i in feature_indices]} ****")
    model.fit(X_poly[:, feature_indices], Y)
    r_squared = model.score(X_poly[:, feature_indices], Y)
    print("R2 = ", r_squared)
    residual = residual - model.predict(X_poly[:, feature_indices])
    # print(residual)
    print("Residual is updated ")

# Any relationship between the final residual and the unused variables?
print("Making scatter plot: age_of_roof vs final residual")
fig, ax = plt.subplots()
ax.scatter(X_basic[:, 3], residual, marker="+")
fig.savefig("ResidualRoof.png")

print("Making a scatter plot: miles_from_school vs final residual")
fig, ax = plt.subplots()
ax.scatter(X_basic[:, 4], residual, marker="+")
fig.savefig("ResidualMiles.png")

