import numpy as np
from sklearn.linear_model import LinearRegression
from scipy.stats import kstest, norm
import matplotlib.pyplot as plt
import sys
import util
from scipy.sparse.linalg import lsqr as sparse_lsqr

# Check command line
if len(sys.argv) != 2:
    print(f"{sys.argv[0]} <xlsx>")
    exit(1)

# Read in the argument
infilename = sys.argv[1]

# Read the spreadsheet
X, Y, labels = util.read_excel_data(infilename)

n, d = X.shape
print(f"Read {n} rows, {d-1} features from '{infilename}'.")

# Don't need the intercept added -- X has column of 1s
lin_reg = LinearRegression(fit_intercept=False)

# Fit the model
lin_reg.fit(X, Y)

# Pretty print coefficients
print(util.format_prediction(lin_reg.coef_, labels))

# Get residual
## Your code here
prediction_residual = lin_reg.predict(X)
residual = Y - prediction_residual


# Make a histogram of the residual and save as "res_hist.png"
## Your code here
col_name = residual / 1000
title = "Residual Histogram"
fig, axs = plt.subplots()
axs.set_title(title)
axs.set_xlabel("Residual")
axs.set_ylabel("Density")
# axs.yaxis.set_ticks(np.arrange(0, 90, 10))
axs.xaxis.set_major_formatter("${x:0.0f}K")
n, bins, patches = axs.hist(col_name, bins=18, density=False)
plt.savefig("res_hist.png")

# Do a Kolmogorov-Smirnov to see if the residual is normally
# distributed
## Your code here
res = kstest(residual, norm.cdf)
print(f"Kolmogorov-Smirov: P-value = {res.pvalue}")
if res.pvalue < 0.05:
    print("\tThe residual follows a normal distribution")
else:
    print("\t The residual does not follow a normal distribution.")
# Calculate the standard deviation
## Your code here
standard_deviation = residual.std(axis=0)

print(
    f"68% of predictions with this formula will be within ${standard_deviation:,.02f} of the actual price."
)
print(
    f"95% of predictions with this formula will be within ${2.0 * standard_deviation:,.02f} of the actual price."
)
