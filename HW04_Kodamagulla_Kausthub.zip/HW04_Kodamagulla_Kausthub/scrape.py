import sys
import requests as rq
from bs4 import BeautifulSoup as bs
import pandas as pd
import openpyxl

if len(sys.argv) < 3:
    print("Usage: python3 scrape.py <date> <xslx>")
    exit(1)

desired_date = sys.argv[1]
outpath = sys.argv[2]

url = "https://discoveratlanta.com/events/all/"

## Your code here
web_page = rq.get(url)

sheet_data = {"title": [], "link": []}
sp_obj = bs(web_page.content, "html.parser")
events_list = sp_obj.find_all("article", class_="listing")
for event in events_list:
    if event["data-eventdates"].find(desired_date) != -1:
        sheet_data["title"].append(event.find("h4", class_="listing-title").getText())
        sheet_data["link"].append(
            event.find("h4", class_="listing-title").find("a").attrs["href"]
        )

df1 = pd.DataFrame(sheet_data)
sheetname = "Events"
df1.to_excel(outpath, sheet_name=sheetname, index=False)

wa = openpyxl.load_workbook(filename=outpath)
work_sheet = wa.active
for col in work_sheet.columns:
    max_length = 0
    column = col[0].column_letter
    work_sheet.column_dimensions[column].width = 50

wa.save('result.xlsx')