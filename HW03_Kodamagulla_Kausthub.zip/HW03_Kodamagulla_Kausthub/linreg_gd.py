import numpy as np
import pandas as pd
import sys
import util
import matplotlib.pyplot as plt

# Check the command line
if len(sys.argv) != 2:
    print(f"{sys.argv[0]} <xlsx>")
    exit(1)

# Learning rate
t = 0.001

# Limit interations
max_steps = 1000

# Get the arg and read in the spreadsheet
infilename = sys.argv[1]
X, Y, labels = util.read_excel_data(infilename)
n, d = X.shape
print(f"Read {n} rows, {d - 1} features from '{infilename}'.")

# Get the mean and standard deviation for each column
## Your code here
X_mean = np.mean(X, axis=0)[1:]
X_std = np.std(X, axis=0)[1:]

# Don't mess with the first column (the 1s)
## Your code here
row_count, coulmn_count = X.shape

# Standardize X to be X'
Xp = np.concatenate(
    (
        np.ones((row_count, 1)),
        np.divide(np.subtract(X[:, 1:], X_mean), X_std),
    ),
    axis=1,
)

# First guess for B is "all coefficents are zero"
B = np.zeros(coulmn_count, dtype=int)

# Create a numpy array to record avg error for each step
errors = np.array([np.square(Y - np.dot(B, Xp.T)).mean()])
for i in range(max_steps):

    # Compute the gradient
    gradient = np.dot(Xp.T, np.dot(Xp, B) - Y)

    # Compute a new B (use `t`)
    B = B - t * gradient

    # Figure out the average squared error using the new B
    predict_price = np.dot(B, Xp.T)
    err = np.square(Y - predict_price).mean()

    # Store it in `errors``
    errors = np.append(errors, err)

    # Check to see if we have converged
    if round(errors[errors.size - 2], 2) - round(errors[errors.size - 1], 2) == 0:
        break

print(f"Took {i} iterations to converge")

# "Unstandardize" the coefficients
B = np.concatenate(
    (
        np.array([B[0] - np.dot(B[1:], np.divide(X_mean, X_std))]),
        np.divide(B[1:], X_std),
    ),
    axis=0,
)

# Show the result
print(util.format_prediction(B, labels))

# Get the R2 score
R2 = util.score(B, X, Y)
print(f"R2 = {R2:f}")

# Draw a graph
fig1 = plt.figure(1, (4.5, 4.5))
## Your code ehre
axs1 = plt.axes()
axs1.plot([i for i in range(errors[1:].size)], errors[1:])
axs1.set_title("Graph")
axs1.set_xlabel("Iterative Points")
axs1.set_xscale("log")
axs1.set_ylabel("MSE")
axs1.set_yscale("log")
fig1.savefig("err.png")
