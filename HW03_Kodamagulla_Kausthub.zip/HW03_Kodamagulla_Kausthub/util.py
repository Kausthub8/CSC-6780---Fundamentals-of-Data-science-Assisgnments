import pandas as pd
import numpy as np

# Read in the excel file
# Returns:
#   X: first column is 1s, the rest are from the spreadsheet
#   Y: The last column from the spreadsheet
#   labels: The list of headers for the columns of X from the spreadsheet
def read_excel_data(infilename):
    ## Your code here
    df = pd.read_excel(infilename, index_col="property_id")
    labels = list(df.columns.values)

    first_columns = df.iloc[:, : len(labels) - 1]
    first_columns.insert(loc=0, column="Col_one", value=1)
    first_columns = first_columns.to_numpy()

    last_column = df.iloc[:, -1].to_numpy()

    return first_columns, last_column, labels


# Make it pretty
def format_prediction(B, labels):
    ## Your code here
    pred_string = f"predicted price = ${round(B[0],2):,} + (${round(B[1],2):,} * sqft_hvac) + (${round(B[2],2):,} * sqft_yard) + (${round(B[3],2):,} * bedrooms) + (${round(B[4],2):,} * bathrooms) + (${round(B[5],2):,} * miles_to_school)"
    return pred_string


# Return the R2 score for coefficients B
# Given inputs X and outputs Y
def score(B, X, Y):
    ## Your code here
    my_predict_price = np.dot(B, X.T)
    mean_original_price = np.mean(Y)
    cal_numerator = np.sum(np.square(Y - my_predict_price))
    cal_denominator = np.sum(np.square(Y - mean_original_price))
    R2 = 1 - (cal_numerator / cal_denominator)
    return R2
