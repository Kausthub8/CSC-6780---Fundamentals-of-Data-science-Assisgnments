import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import ConfusionMatrixDisplay, confusion_matrix, accuracy_score
import matplotlib.pyplot as plt
import pickle

# Read in the testing data
df = pd.read_csv("test_breast.csv", index_col="id")
X_test = df.drop(columns=["diagnosis"])
y_test = df["diagnosis"]
print(f"X shape = {X_test.shape}, y shape={y_test.shape}")

# Read in the scaler and the SVC
## Your code here
with open("classifier.pkl", "rb") as file:
    scaler = pickle.load(file)
    classifier = pickle.load(file)

# Scale the input data
X_test_scaled = scaler.fit_transform(X_test)

# Do a prediction using the test data
y_pred = classifier.predict(X_test_scaled)

# Show the accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy on testing data = {accuracy * 100.0:.2f}%")

# Make a confusion matrix
cm = confusion_matrix(y_test, y_pred)
print(f"Confusion on testing data: \n{cm}")

# Make it into a pretty plot
fig, ax = plt.subplots(figsize=(9, 7))
labels = ["Benign", "Malignant"]
display = ConfusionMatrixDisplay(cm, display_labels=labels)
ax.set_xlabel("Predicted Label")
ax.set_ylabel("True Label")
ax.set_title("Breast Cancer Confusion Matrix(testing data)")
display.plot(ax=ax, cmap="Blues", colorbar=False)


fig.savefig("test_confusion.png")
print("Wrote test_confusion.png")
